import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

import { DataService } from '../services/data.service';
import { ToastComponent } from '../shared/toast/toast.component';
import { Data } from '../shared/models/data.model';

@Component({
  selector: 'app-cats',
  templateUrl: './data.component.html',
  styleUrls: ['./data.component.scss']
})
export class DataComponent implements OnInit {

  data: Data[] = [];
  isLoading = true;
  isEditing = false;

  addDataForm1: FormGroup;
  addDataForm2: FormGroup;
  data1 = new FormControl('', Validators.required);
  data2 = new FormControl('', Validators.required);
  constructor(private dataService: DataService,
              private formBuilder: FormBuilder,
              public toast: ToastComponent) { }

  ngOnInit() {
    this.getData();
    this.addDataForm1 = this.formBuilder.group({
      data1: this.data1
    });

    this.addDataForm2 = this.formBuilder.group({
      data2: this.data2
    });
  }

  getData() {
    this.dataService.getData().subscribe(
      data => this.data = data,
      error => console.log(error),
      () => this.isLoading = false
    );
  }

  addData(type) {
    const result = (type === 'type2') ? this.addDataForm2.controls.data2.value : this.addDataForm1.controls.data1.value;
    let items;
    let resultData = {};
    if(type === 'type2') {
      items = result.split(0, 9);
      items = items.filter((data) => Boolean(data));
      resultData = {
        firstName: items[0],
        lastName: items[1],
        contact: items[2]
      }
      this.dataService.addDataV2(resultData).subscribe(
        res => {
          this.data.push(res);
          this.addDataForm2.reset();
          this.toast.setMessage('item added successfully.', 'success');
        },
        error => console.log(error)
      );
    } else {
      resultData = {
        firstName: result.slice(0, 8),
        lastName: result.slice(8, 18),
        contact: result.slice(18, 25)
      }
      this.dataService.addDataV1(resultData).subscribe(
        res => {
          this.data.push(res);
          this.addDataForm1.reset();
          this.toast.setMessage('item added successfully.', 'success');
        },
        error => console.log(error)
      );
    }
  }
}
