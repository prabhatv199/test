import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Data } from '../shared/models/data.model';

@Injectable()
export class DataService {

  constructor(private http: HttpClient) { }

  getData(): Observable<Data[]> {
    return this.http.get<Data[]>('/api/v1/parse');
  }
  addDataV1(data: Data): Observable<Data> {
    return this.http.post<Data>('/api/v1/parse', data);
  }
  addDataV2(data: Data): Observable<Data> {
    return this.http.post<Data>('/api/v2/parse', data);
  }
}
