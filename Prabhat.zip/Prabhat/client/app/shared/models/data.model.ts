export class Data {
  // tslint:disable-next-line: variable-name
  _id?: string;
  firstName?: string;
  lastName?: string;
  contact?: number;
}
