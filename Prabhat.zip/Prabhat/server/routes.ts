import * as express from 'express';

import DataCtrl from './controllers/data';

export default function setRoutes(app) {

  const router = express.Router();

  const dataCtrl = new DataCtrl();

  // Cats
  router.route('/v1/parse').get(dataCtrl.getAll);
  router.route('/v1/parse').post(dataCtrl.insert);
  router.route('/v2/parse').post(dataCtrl.insert);


  // Apply the routes to our application with the prefix /api
  app.use('/api', router);

}
