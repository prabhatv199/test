import * as mongoose from 'mongoose';

const dataSchema = new mongoose.Schema({
  firstName: String,
  lastName: String,
  contact: Number
});

const Data = mongoose.model('Data', dataSchema);

export default Data;
