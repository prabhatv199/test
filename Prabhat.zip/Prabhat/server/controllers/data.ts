import Data from '../models/data';
import BaseCtrl from './base';

export default class CatCtrl extends BaseCtrl {
  model = Data;
}
